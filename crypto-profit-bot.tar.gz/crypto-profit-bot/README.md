# Crypto Profit Bot

**Crypto Profit Bot** is a Python‑based trading bot designed to monitor
cryptocurrency markets, generate take‑profit and stop‑loss signals and
rebalance a portfolio automatically. It supports both centralised
exchanges (CEX) via [CCXT](https://github.com/ccxt/ccxt) and on‑chain
decentralised exchanges (DEX) via [Web3.py](https://github.com/ethereum/web3.py).

> **Disclaimer:** This project is provided for educational purposes only.
> Trading digital assets carries risk. You are solely responsible for
> understanding and managing your own risk. Use at your own risk.

## Features

- Poll market prices every five seconds from a configurable CEX and
  optionally from an on‑chain DEX.
- Generate simple take‑profit or stop‑loss signals based on entry price
  and configurable thresholds.
- Execute market or limit orders via CEX API or swap tokens on‑chain via
  a DEX router contract.
- Periodically rebalance your portfolio towards target weights when
  allocations drift beyond a configured threshold.
- Persist state (entry prices, in‑position flags, rebalance timestamps)
  using Redis (if available) or fallback to SQLite.
- Clean, modular code with unit tests and automated CI pipeline.

## Getting Started

### Prerequisites

The bot requires Python 3.9 or newer. Install dependencies using pip:

```bash
pip install -r requirements.txt
```

Alternatively you can run the bot inside Docker; see the
[Docker](#docker) section below.

### Configuration

The bot reads all configuration from environment variables. At a
minimum you must define API keys for your CEX and specify target
weights. The following variables are recognised:

| Variable              | Required | Description                                                                                       |
|-----------------------|----------|---------------------------------------------------------------------------------------------------|
| `CEX_API_KEY`         | Yes      | API key for your centralised exchange (e.g. Binance).                                             |
| `CEX_SECRET`          | Yes      | API secret for your centralised exchange.                                                         |
| `ETH_RPC_URL`         | No       | HTTP RPC endpoint for Ethereum (needed only for on‑chain swaps).                                  |
| `BOT_OWNER_ADDRESS`   | No       | Ethereum address used to perform on‑chain swaps.                                                  |
| `PRIVATE_KEY`         | No       | Private key corresponding to `BOT_OWNER_ADDRESS`.                                                 |
| `X_TAKE_PROFIT`       | No       | Take‑profit threshold as a percentage (e.g. `5` for 5%).                                          |
| `Y_STOP_LOSS`         | No       | Stop‑loss threshold as a percentage (e.g. `2` for 2%).                                            |
| `Z_DRIFT_THRESHOLD`   | No       | Rebalance drift threshold as a percentage (e.g. `1` for 1%).                                      |
| `TARGET_WEIGHTS`      | Yes      | JSON mapping of asset symbols to target weights that sum to 1, e.g. `{"BTC/USDT": 0.5, "ETH/USDT": 0.5}`. |
| `REDIS_URL`           | No       | URL for a Redis instance to persist state. If omitted, SQLite is used.                           |

Set these variables in your environment or define them in a `.env` file
and use [python‑dotenv](https://github.com/theskumar/python-dotenv) to load them.

### Running Locally

After installing dependencies and defining environment variables you can
start the bot with:

```bash
python -m crypto_profit_bot.main
```

The bot will start monitoring the first symbol defined in
`TARGET_WEIGHTS`, enter a position at the first price tick and then
evaluate take‑profit/stop‑loss signals on each update. Every five
minutes it computes rebalancing orders using your configured target
weights and drift threshold. Logs are printed to stdout.

### Docker

You can run the bot and a Redis server using Docker Compose. First
ensure Docker and Docker Compose are installed on your machine. Then run:

```bash
docker compose up --build
```

This will build the bot image, start a Redis container and run the bot
service. You can override environment variables in `docker-compose.yml`
or by setting them on the command line when invoking `docker compose`.

### Testing

Unit tests are provided in the `tests/` directory and can be executed
with [pytest](https://docs.pytest.org/):

```bash
pytest
```

The test suite includes basic checks for configuration parsing, signal
logic, state persistence and rebalance calculation. Network calls are
mocked out or skipped when dependencies are missing.

### Continuous Integration

GitHub Actions is configured via `.github/workflows/ci.yml` to run
flake8, black (in check mode) and pytest on every pull request. This
helps ensure code quality and prevent regressions. You can run the same
checks locally via:

```bash
flake8 crypto_profit_bot
black --check crypto_profit_bot
pytest
```

### Troubleshooting

- **No prices received:** Ensure your internet connection is working and
  that the exchange API is reachable. If you are behind a firewall
  inspect network settings.
- **Failed to place order:** Check that your API key and secret are
  correct and that your account has sufficient balance. Exchanges may
  also impose additional restrictions such as IP whitelisting.
- **State not persisted between restarts:** Verify that Redis is
  reachable via `REDIS_URL` or that the process has write permissions
  for the SQLite database file (`state.db`).

## License

This project is licensed under the MIT License – see the
[LICENSE](LICENSE) file for details.