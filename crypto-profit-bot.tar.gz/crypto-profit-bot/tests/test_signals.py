from crypto_profit_bot.signals import take_profit_or_stop_loss


def test_take_profit_triggered():
    # Entry price 100, current price 105 (5% profit), threshold 5 -> sell
    decision = take_profit_or_stop_loss(100, 105, x_take_profit=5, y_stop_loss=2)
    assert decision == "sell"


def test_stop_loss_triggered():
    # Entry price 100, current price 97 (3% drop), stop loss at 2% -> sell
    decision = take_profit_or_stop_loss(100, 97, x_take_profit=10, y_stop_loss=2)
    assert decision == "sell"


def test_hold_when_no_thresholds_breached():
    # Entry price 100, current price 101 -> hold (profit < 5%)
    decision = take_profit_or_stop_loss(100, 101, x_take_profit=5, y_stop_loss=2)
    assert decision == "hold"


def test_hold_when_missing_prices():
    assert take_profit_or_stop_loss(None, 100, 5, 2) == "hold"
    assert take_profit_or_stop_loss(100, None, 5, 2) == "hold"