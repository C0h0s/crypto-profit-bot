from crypto_profit_bot.rebalance import generate_rebalance_orders


def test_generate_rebalance_orders_no_rebalance():
    balances = {"BTC": 1.0, "ETH": 2.0}
    prices = {"BTC": 100.0, "ETH": 50.0}
    target_weights = {"BTC": 0.5, "ETH": 0.5}
    threshold = 10  # 10% threshold
    orders = generate_rebalance_orders(balances, prices, target_weights, threshold)
    assert orders == []  # current weights: BTC=0.5, ETH=0.5 -> no drift


def test_generate_rebalance_orders_with_drift():
    balances = {"BTC": 2.0, "ETH": 0.5}
    prices = {"BTC": 100.0, "ETH": 100.0}
    target_weights = {"BTC": 0.5, "ETH": 0.5}
    threshold = 1  # 1% threshold
    orders = generate_rebalance_orders(balances, prices, target_weights, threshold)
    # BTC weight = 2*100/(2*100+0.5*100)=200/250=0.8 -> drift 0.3 -> sell some BTC
    # ETH weight = 0.5*100/250=0.2 -> drift -0.3 -> buy some ETH
    assert len(orders) == 2
    sides = sorted([o.side for o in orders])
    assert sides == ["buy", "sell"]