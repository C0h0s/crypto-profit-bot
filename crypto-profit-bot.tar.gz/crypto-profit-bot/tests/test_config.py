import os
from crypto_profit_bot.config import Config


def test_config_from_env(monkeypatch):
    monkeypatch.setenv("CEX_API_KEY", "key123")
    monkeypatch.setenv("CEX_SECRET", "secret456")
    monkeypatch.setenv("ETH_RPC_URL", "http://localhost:8545")
    monkeypatch.setenv("BOT_OWNER_ADDRESS", "0x123")
    monkeypatch.setenv("PRIVATE_KEY", "0xabc")
    monkeypatch.setenv("X_TAKE_PROFIT", "5")
    monkeypatch.setenv("Y_STOP_LOSS", "2")
    monkeypatch.setenv("Z_DRIFT_THRESHOLD", "1.5")
    monkeypatch.setenv("TARGET_WEIGHTS", '{"BTC/USDT": 0.6, "ETH/USDT": 0.4}')
    cfg = Config.from_env()
    assert cfg.cex_api_key == "key123"
    assert cfg.cex_secret == "secret456"
    assert cfg.eth_rpc_url == "http://localhost:8545"
    assert cfg.bot_owner_address == "0x123"
    assert cfg.private_key == "0xabc"
    assert cfg.x_take_profit == 5.0
    assert cfg.y_stop_loss == 2.0
    assert cfg.z_drift_threshold == 1.5
    assert cfg.target_weights == {"BTC/USDT": 0.6, "ETH/USDT": 0.4}