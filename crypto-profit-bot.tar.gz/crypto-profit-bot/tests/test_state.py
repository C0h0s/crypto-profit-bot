import os
import tempfile

from crypto_profit_bot.state import StateManager


def test_state_sqlite_set_get():
    # Use a temporary file for SQLite
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "state.db")
        sm = StateManager(redis_url=None, db_path=db_path)
        sm.set("foo", {"bar": 123})
        assert sm.get("foo") == {"bar": 123}
        assert sm.get("missing", default=42) == 42


def test_state_entry_position_helpers():
    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = os.path.join(tmpdir, "state.db")
        sm = StateManager(redis_url=None, db_path=db_path)
        sm.set_entry_price("BTC/USDT", 100.0)
        assert sm.get_entry_price("BTC/USDT") == 100.0
        sm.set_in_position("BTC/USDT", True)
        assert sm.get_in_position("BTC/USDT") is True
        sm.set_last_rebalance(123.456)
        assert sm.get_last_rebalance() == 123.456