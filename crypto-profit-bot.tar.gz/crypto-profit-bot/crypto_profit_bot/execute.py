"""Order execution functions for the crypto‑profit trading bot.

This module encapsulates the logic required to place orders on both
centralised exchanges via CCXT and on‑chain decentralised exchanges via
Web3. It takes care of constructing the appropriate request payloads,
handling nonces, gas estimation and retries where applicable. The
functions here are intentionally stateless; any state such as nonces or
position entries should be maintained by callers or by the state manager.

Note that real order execution requires valid API keys, sufficient
balances and connectivity to the chosen exchange or blockchain network.
During unit testing these functions should be monkey‑patched to avoid
actual network calls.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, List, Optional

try:
    import ccxt  # type: ignore
except ImportError:  # pragma: no cover
    ccxt = None  # type: ignore

try:
    from web3 import Web3  # type: ignore
    from web3.exceptions import TransactionNotFound  # type: ignore
except ImportError:  # pragma: no cover
    Web3 = None  # type: ignore
    TransactionNotFound = Exception  # type: ignore

logger = logging.getLogger(__name__)


def create_cex_order(
    exchange: Any,
    side: str,
    symbol: str,
    amount: float,
    price: Optional[float] = None,
    **kwargs: Any,
) -> Dict[str, Any]:
    """Create a market or limit order on a centralised exchange.

    Parameters
    ----------
    exchange : ccxt.Exchange
        Instance of a CCXT exchange client that has been authenticated.
    side : str
        Either ``"buy"`` or ``"sell"``.
    symbol : str
        Trading pair symbol (e.g. ``"BTC/USDT"``).
    amount : float
        Quantity of the base currency to trade.
    price : float, optional
        Limit price. If provided a limit order is created, otherwise a market
        order is submitted.
    **kwargs : Any
        Additional keyword arguments to pass to the CCXT ``create_order`` call.

    Returns
    -------
    dict
        The exchange's response to the order creation request.
    """
    if ccxt is None:
        raise RuntimeError("ccxt is not installed")
    order_type = "limit" if price is not None else "market"
    params = kwargs.copy()
    try:
        if order_type == "limit":
            result = exchange.create_limit_order(symbol, side, amount, price, params)
        else:
            result = exchange.create_market_order(symbol, side, amount, params)
        return result
    except Exception as exc:
        logger.exception("Error placing CEX order: %s", exc)
        raise


def swap_exact_tokens_for_tokens(
    web3: Any,
    router_contract: Any,
    amount_in: int,
    amount_out_min: int,
    path: List[str],
    account: str,
    private_key: str,
    gas_multiplier: float = 1.2,
    deadline_seconds: int = 600,
) -> str:
    """Swap tokens on a DEX via a router contract.

    This function performs an on‑chain swap using the ``swapExactTokensForTokens``
    method exposed by many DEX router contracts (e.g. UniswapV2 router). It
    handles gas estimation, nonce calculation and signing/broadcasting of the
    transaction. The caller must ensure that ``amount_in`` and ``amount_out_min``
    are expressed in token base units (e.g. wei for ERC‑20 tokens).

    Parameters
    ----------
    web3 : Web3
        Instantiated Web3 provider.
    router_contract : web3.contract.Contract
        Router contract instance exposing ``swapExactTokensForTokens``.
    amount_in : int
        Amount of input tokens to swap (in smallest units).
    amount_out_min : int
        Minimum amount of output tokens to receive (slippage tolerance).
    path : List[str]
        Address path of tokens to swap through.
    account : str
        Address performing the swap.
    private_key : str
        Private key corresponding to ``account``.
    gas_multiplier : float
        Factor by which to multiply the estimated gas to provide a buffer.
    deadline_seconds : int
        Seconds from now until which the swap remains valid.

    Returns
    -------
    str
        Transaction hash of the submitted swap.
    """
    if Web3 is None:
        raise RuntimeError("web3 is not installed")
    nonce = web3.eth.get_transaction_count(account)
    deadline = int(time.time()) + deadline_seconds
    tx = router_contract.functions.swapExactTokensForTokens(
        amount_in, amount_out_min, path, account, deadline
    ).build_transaction({
        "from": account,
        "nonce": nonce,
    })
    # Estimate gas and add a buffer
    gas_estimate = web3.eth.estimate_gas(tx)
    tx["gas"] = int(gas_estimate * gas_multiplier)
    # Gas price: use node's suggestion
    tx["gasPrice"] = web3.eth.gas_price
    # Sign and send transaction
    signed = web3.eth.account.sign_transaction(tx, private_key=private_key)
    tx_hash = web3.eth.send_raw_transaction(signed.rawTransaction)
    return tx_hash.hex()