"""Market monitoring utilities.

This module defines classes and functions for polling prices from both
centralised exchanges (CEX) via CCXT and on‑chain decentralised exchanges
(DEX) via Web3. Price updates are normalised to a common quote currency
("USDT" by default) to facilitate comparison. Consumers of this module
should register callbacks to receive updates for the symbols or trading
pairs they care about.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Callable, Dict, Iterable, List, Optional

try:
    import ccxt  # type: ignore
except ImportError:  # pragma: no cover - gracefully handle missing ccxt during testing
    ccxt = None  # type: ignore

try:
    from web3 import Web3  # type: ignore
except ImportError:  # pragma: no cover - gracefully handle missing web3 during testing
    Web3 = None  # type: ignore

logger = logging.getLogger(__name__)


class PriceMonitor:
    """Poll prices from CEX and DEX at a fixed interval.

    Parameters
    ----------
    cex_symbol : str
        Symbol on the centralised exchange to monitor, e.g. ``"BTC/USDT"``.
    dex_path : List[str], optional
        Token addresses describing the path for a swap on a DEX when
        computing on‑chain prices via ``getAmountsOut``. The first element
        should be the token you are selling; the last should be USDT or
        your stablecoin of choice.
    web3_provider_url : str, optional
        Ethereum RPC endpoint used to instantiate a Web3 client. If not
        provided, on‑chain price monitoring will be skipped.
    router_address : str, optional
        Address of the DEX router contract implementing ``getAmountsOut``.
    router_abi : List[dict], optional
        ABI for the router contract. If not supplied, a minimal ABI
        containing only ``getAmountsOut`` will be used.
    interval_seconds : int
        How often to poll prices. Default is 5 seconds.
    """

    DEFAULT_DEX_ROUTER_ABI = [
        {
            "name": "getAmountsOut",
            "outputs": [
                {"internalType": "uint256[]", "name": "amounts", "type": "uint256[]"}
            ],
            "inputs": [
                {"internalType": "uint256", "name": "amountIn", "type": "uint256"},
                {"internalType": "address[]", "name": "path", "type": "address[]"},
            ],
            "stateMutability": "view",
            "type": "function",
        }
    ]

    def __init__(
        self,
        cex_symbol: str,
        dex_path: Optional[List[str]] = None,
        web3_provider_url: Optional[str] = None,
        router_address: Optional[str] = None,
        router_abi: Optional[List[dict]] = None,
        interval_seconds: int = 5,
    ) -> None:
        self.cex_symbol = cex_symbol
        self.dex_path = dex_path
        self.interval_seconds = interval_seconds

        # Initialise CEX exchange (default to Binance if available)
        if ccxt is not None:
            try:
                self.cex = ccxt.binance()
            except Exception:  # pragma: no cover - other exchanges fall back
                self.cex = None
        else:
            self.cex = None

        # Initialise Web3 and router contract if parameters provided
        self.web3 = None
        self.router = None
        if Web3 is not None and web3_provider_url and router_address and dex_path:
            try:
                self.web3 = Web3(Web3.HTTPProvider(web3_provider_url))
                abi = router_abi or self.DEFAULT_DEX_ROUTER_ABI
                self.router = self.web3.eth.contract(address=router_address, abi=abi)
            except Exception as exc:
                logger.warning("Failed to initialise Web3 or router: %s", exc)
                self.web3 = None
                self.router = None

        self._callbacks: List[Callable[[float, float], None]] = []
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def add_callback(self, callback: Callable[[float, float], None]) -> None:
        """Register a callback to receive price updates.

        The callback will be invoked with two positional arguments:
        ``cex_price`` and ``dex_price``. If a price source is unavailable,
        ``None`` will be passed instead.
        """
        self._callbacks.append(callback)

    def _fetch_cex_price(self) -> Optional[float]:
        if not self.cex:
            return None
        try:
            ticker = self.cex.fetch_ticker(self.cex_symbol)
            return float(ticker.get("last"))
        except Exception as exc:  # pragma: no cover - network errors
            logger.warning("Failed to fetch CEX price: %s", exc)
            return None

    def _fetch_dex_price(self) -> Optional[float]:
        if not (self.web3 and self.router and self.dex_path):
            return None
        try:
            # Query 1 unit of the input token; this is arbitrary but gives a ratio
            amount_in = 10 ** 18  # 1 token assuming 18 decimals
            amounts_out: List[int] = self.router.functions.getAmountsOut(
                amount_in, self.dex_path
            ).call()
            # Last element corresponds to USDT or output token; convert back to
            # floating point by dividing by 1e18.
            if not amounts_out:
                return None
            return float(amounts_out[-1]) / (10 ** 18)
        except Exception as exc:  # pragma: no cover - network errors
            logger.warning("Failed to fetch DEX price: %s", exc)
            return None

    def _poll(self) -> None:
        while not self._stop_event.is_set():
            cex_price = self._fetch_cex_price()
            dex_price = self._fetch_dex_price()
            for cb in list(self._callbacks):
                try:
                    cb(cex_price, dex_price)
                except Exception as exc:
                    logger.exception("Exception in price callback: %s", exc)
            time.sleep(self.interval_seconds)

    def start(self) -> None:
        """Start background polling of prices."""
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._poll, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop background polling."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=self.interval_seconds * 2)