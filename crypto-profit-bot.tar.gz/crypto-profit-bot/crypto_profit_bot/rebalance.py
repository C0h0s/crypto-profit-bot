"""Portfolio rebalancing logic.

Rebalancing ensures that the portfolio stays aligned with the desired
target weights within a certain drift threshold. When allocations drift
beyond the configured threshold the bot will calculate the appropriate
buy/sell orders required to restore the portfolio to its targets.

This module does not execute trades directly; it simply computes what
actions should be taken. The execution of those actions should be
performed by the calling code via functions defined in ``execute.py``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class RebalanceOrder:
    """Represents a single rebalance action to be taken."""

    symbol: str
    side: str  # "buy" or "sell"
    amount: float


def compute_portfolio_value(balances: Dict[str, float], prices: Dict[str, float]) -> float:
    """Compute the total value of the portfolio in quote currency."""
    return sum(balances.get(sym, 0) * prices.get(sym, 0) for sym in balances)


def current_weights(balances: Dict[str, float], prices: Dict[str, float]) -> Dict[str, float]:
    """Compute the current weight of each asset in the portfolio."""
    total_value = compute_portfolio_value(balances, prices)
    if total_value == 0:
        # Avoid division by zero; return zero weights
        return {sym: 0.0 for sym in balances}
    return {
        sym: (balances.get(sym, 0) * prices.get(sym, 0)) / total_value
        for sym in balances
    }


def generate_rebalance_orders(
    balances: Dict[str, float],
    prices: Dict[str, float],
    target_weights: Dict[str, float],
    threshold: float,
) -> List[RebalanceOrder]:
    """Calculate a list of rebalance orders required to reach the target weights.

    Parameters
    ----------
    balances : Dict[str, float]
        Current asset balances keyed by symbol.
    prices : Dict[str, float]
        Current asset prices keyed by symbol.
    target_weights : Dict[str, float]
        Desired portfolio weights (must sum to 1). Keys should match ``balances``.
    threshold : float
        Allowed drift before rebalancing, expressed as a percentage (e.g. ``1`` for 1%).

    Returns
    -------
    List[RebalanceOrder]
        A list of orders specifying which assets to buy or sell and in what amount.
        An empty list is returned if no rebalancing is required.
    """
    orders: List[RebalanceOrder] = []
    total_value = compute_portfolio_value(balances, prices)
    if total_value == 0:
        return orders
    curr_weights = current_weights(balances, prices)
    # Convert percentage threshold to decimal
    threshold_decimal = threshold / 100.0
    for sym, target_w in target_weights.items():
        curr_w = curr_weights.get(sym, 0.0)
        drift = curr_w - target_w
        if abs(drift) > threshold_decimal:
            # Determine the value difference that needs to be corrected
            diff_value = total_value * abs(drift)
            # Convert value difference to asset amount
            price = prices.get(sym, 0.0)
            if price <= 0:
                continue
            amount = diff_value / price
            side = "sell" if drift > 0 else "buy"
            orders.append(RebalanceOrder(symbol=sym, side=side, amount=amount))
    return orders