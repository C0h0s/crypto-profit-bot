"""Entrypoint for running the crypto‑profit bot.

The main function wires together all of the modules: it loads configuration
from the environment, initialises state storage, starts price monitoring,
checks for take‑profit and stop‑loss signals and triggers rebalancing on
a periodic basis. Errors are logged and propagated via optional alerting
hooks (webhooks or Discord) which can be added in the future.
"""

from __future__ import annotations

import logging
import os
import signal
import sys
import time
from typing import Optional

from apscheduler.schedulers.background import BackgroundScheduler

from .config import Config
from .execute import create_cex_order, swap_exact_tokens_for_tokens
from .monitor import PriceMonitor
from .rebalance import generate_rebalance_orders
from .signals import take_profit_or_stop_loss
from .state import StateManager

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s: %(message)s")


def run_bot() -> None:
    config = Config.from_env()
    state = StateManager(redis_url=os.getenv("REDIS_URL"))
    # For demonstration we monitor a single symbol on the CEX
    # Users can customise these via configuration or extend to multiple symbols
    symbol = next(iter(config.target_weights.keys()), "BTC/USDT")
    monitor = PriceMonitor(cex_symbol=symbol)

    # Exchange instance is initialised here when needed; this ensures API
    # credentials are loaded only if we attempt to place an order.
    exchange = None

    def on_price_update(cex_price: Optional[float], dex_price: Optional[float]) -> None:
        """Callback invoked on each price update from the monitor."""
        nonlocal exchange
        current_price = cex_price or dex_price
        if current_price is None:
            logger.debug("No price available yet")
            return
        entry_price = state.get_entry_price(symbol)
        in_position = state.get_in_position(symbol)
        # If we're not in a position yet, record the entry price and mark that
        # we've entered. In a real bot you would decide when to enter using
        # technical indicators or user input; here we assume entry at the
        # first price tick.
        if not in_position and entry_price is None:
            state.set_entry_price(symbol, current_price)
            state.set_in_position(symbol, True)
            logger.info("Entering position in %s at price %.4f", symbol, current_price)
            return
        # Evaluate take‑profit/stop‑loss
        decision = take_profit_or_stop_loss(
            entry_price=entry_price,
            current_price=current_price,
            x_take_profit=config.x_take_profit,
            y_stop_loss=config.y_stop_loss,
        )
        if decision == "sell" and in_position:
            logger.info(
                "Take‑profit/stop‑loss triggered at %.4f (entry %.4f)",
                current_price,
                entry_price,
            )
            # Lazily initialise exchange
            if exchange is None:
                import ccxt  # type: ignore

                exchange = ccxt.binance({
                    "apiKey": config.cex_api_key,
                    "secret": config.cex_secret,
                })
            try:
                # For demonstration we close the entire position
                amount = 1.0  # placeholder amount
                create_cex_order(exchange, "sell", symbol, amount)
                logger.info("Placed market sell order for %s %s", amount, symbol)
                # Reset state after exiting position
                state.set_in_position(symbol, False)
                state.set_entry_price(symbol, None)
            except Exception as exc:
                logger.error("Failed to execute sell order: %s", exc)

    # Schedule periodic rebalancing
    def rebalance_job() -> None:
        balances = {}  # In real usage query balances from exchange or wallet
        prices = {}  # Populate with latest prices for each asset
        # Without balances/prices there is nothing to rebalance
        if not balances or not prices:
            return
        orders = generate_rebalance_orders(
            balances=balances,
            prices=prices,
            target_weights=config.target_weights,
            threshold=config.z_drift_threshold,
        )
        for order in orders:
            logger.info(
                "Rebalance: %s %s of %s", order.side, order.amount, order.symbol
            )
            # Execution of rebalance orders would occur here via create_cex_order

    # Start price monitoring and scheduler
    monitor.add_callback(on_price_update)
    monitor.start()
    scheduler = BackgroundScheduler()
    # Run rebalance_job every 5 minutes
    scheduler.add_job(rebalance_job, "interval", minutes=5, id="rebalance")
    scheduler.start()
    logger.info("Bot started – monitoring and scheduled rebalancing active")

    # Graceful shutdown on SIGINT/SIGTERM
    def shutdown(signum: int, frame: object) -> None:
        logger.info("Received signal %s: shutting down", signum)
        monitor.stop()
        scheduler.shutdown()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)
    # Keep the main thread alive
    while True:
        time.sleep(1)


if __name__ == "__main__":  # pragma: no cover - allow running from CLI
    run_bot()