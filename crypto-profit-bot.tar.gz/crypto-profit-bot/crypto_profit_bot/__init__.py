"""Top level package for the crypto‑profit trading bot.

This package exposes modules used throughout the bot including configuration
management, price monitoring, signal generation, order execution, portfolio
rebalancing and state persistence.

To run the bot simply execute ``python -m crypto_profit_bot.main`` after
setting the appropriate environment variables. See README.md for further
instructions.
"""

__all__ = [
    "config",
    "monitor",
    "signals",
    "execute",
    "rebalance",
    "state",
    "main",
]