"""Configuration loader for the crypto‑profit trading bot.

This module centralises access to configuration values used throughout the
project. Configuration is primarily read from environment variables. Where
available, values are parsed into appropriate Python types (for example
``TARGET_WEIGHTS`` is expected to be a JSON string and will be parsed into
a dictionary).

If you would like to load secrets from another source such as a secrets
manager, subclass :class:`Config` and override the ``_load`` method.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class Config:
    """Container for bot configuration values.

    Attributes are populated from environment variables. All percentages are
    expressed as whole numbers (e.g. ``X_TAKE_PROFIT=5`` means take profit at
    ``entry_price * 1.05``).
    """

    cex_api_key: Optional[str] = field(default=None)
    cex_secret: Optional[str] = field(default=None)
    eth_rpc_url: Optional[str] = field(default=None)
    bot_owner_address: Optional[str] = field(default=None)
    private_key: Optional[str] = field(default=None)
    x_take_profit: float = field(default=0.0)
    y_stop_loss: float = field(default=0.0)
    z_drift_threshold: float = field(default=0.0)
    target_weights: Dict[str, float] = field(default_factory=dict)

    def __post_init__(self) -> None:
        # Convert percentage strings to floats dividing by 100 if necessary
        # Accept both integer and float strings; default to 0.0 when missing
        def _to_float(value: Optional[str]) -> float:
            if value is None or value == "":
                return 0.0
            try:
                return float(value)
            except ValueError:
                raise ValueError(f"Invalid numeric value in config: {value}")

        self.x_take_profit = _to_float(self.x_take_profit)
        self.y_stop_loss = _to_float(self.y_stop_loss)
        self.z_drift_threshold = _to_float(self.z_drift_threshold)
        # When provided as percentages like "5" meaning 5%, convert to decimal
        # (so internal logic can multiply by 1 + value/100). This conversion
        # happens in the signals and rebalance modules.

    @classmethod
    def from_env(cls) -> "Config":
        """Load configuration from environment variables.

        The following environment variables are recognised:

        - ``CEX_API_KEY``: API key for the centralised exchange.
        - ``CEX_SECRET``: API secret for the centralised exchange.
        - ``ETH_RPC_URL``: HTTP RPC URL for an Ethereum node.
        - ``BOT_OWNER_ADDRESS``: Address used for on‑chain transactions.
        - ``PRIVATE_KEY``: Private key corresponding to the owner address.
        - ``X_TAKE_PROFIT``: Percentage take‑profit threshold (e.g. "5").
        - ``Y_STOP_LOSS``: Percentage stop‑loss threshold (e.g. "2").
        - ``Z_DRIFT_THRESHOLD``: Drift threshold for rebalancing (e.g. "1").
        - ``TARGET_WEIGHTS``: JSON mapping of symbols to target weights. For
          example ``{"BTC": 0.5, "ETH": 0.3, "USDT": 0.2}``.

        Returns
        -------
        Config
            An instance populated from the current environment.
        """
        env = os.environ
        target_weights_str = env.get("TARGET_WEIGHTS", "{}")
        try:
            target_weights = json.loads(target_weights_str)
            if not isinstance(target_weights, dict):
                raise ValueError
        except (json.JSONDecodeError, ValueError):
            raise ValueError(
                "TARGET_WEIGHTS must be a JSON string mapping symbols to floats"
            )
        return cls(
            cex_api_key=env.get("CEX_API_KEY"),
            cex_secret=env.get("CEX_SECRET"),
            eth_rpc_url=env.get("ETH_RPC_URL"),
            bot_owner_address=env.get("BOT_OWNER_ADDRESS"),
            private_key=env.get("PRIVATE_KEY"),
            x_take_profit=env.get("X_TAKE_PROFIT", "0"),
            y_stop_loss=env.get("Y_STOP_LOSS", "0"),
            z_drift_threshold=env.get("Z_DRIFT_THRESHOLD", "0"),
            target_weights=target_weights,
        )

    def as_dict(self) -> Dict[str, Optional[str]]:
        """Return a dictionary representation of the configuration."""
        return {
            "cex_api_key": self.cex_api_key,
            "cex_secret": self.cex_secret,
            "eth_rpc_url": self.eth_rpc_url,
            "bot_owner_address": self.bot_owner_address,
            "private_key": self.private_key,
            "x_take_profit": self.x_take_profit,
            "y_stop_loss": self.y_stop_loss,
            "z_drift_threshold": self.z_drift_threshold,
            "target_weights": self.target_weights,
        }