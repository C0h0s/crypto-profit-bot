"""State management for the crypto‑profit trading bot.

This module provides a simple abstraction for persisting bot state across
process restarts. It supports both Redis and SQLite backends. The state
includes values such as entry prices, whether a position is open, and the
timestamp of the last rebalance. To minimise complexity the state API
exposes a key/value interface rather than modelling individual fields.
"""

from __future__ import annotations

import json
import os
import sqlite3
from typing import Any, Optional

try:
    import redis  # type: ignore
except ImportError:  # pragma: no cover
    redis = None  # type: ignore


class StateManager:
    """A key/value store backed by Redis or SQLite."""

    def __init__(self, redis_url: Optional[str] = None, db_path: str = "state.db") -> None:
        self.use_redis = False
        self.redis_client: Optional[redis.Redis] = None
        if redis_url and redis is not None:
            try:
                self.redis_client = redis.Redis.from_url(redis_url)
                # Try a ping to ensure connectivity
                self.redis_client.ping()
                self.use_redis = True
            except Exception:
                # Fall back to SQLite
                self.redis_client = None
                self.use_redis = False
        if not self.use_redis:
            # Ensure directory exists
            os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
            self.conn = sqlite3.connect(db_path, check_same_thread=False)
            self.conn.execute(
                "CREATE TABLE IF NOT EXISTS state (key TEXT PRIMARY KEY, value TEXT)"
            )
            self.conn.commit()

    def _serialize(self, value: Any) -> str:
        return json.dumps(value)

    def _deserialize(self, value: Optional[bytes]) -> Any:
        if value is None:
            return None
        try:
            return json.loads(value)
        except (TypeError, ValueError):
            return value

    def set(self, key: str, value: Any) -> None:
        """Set a key to the given value."""
        data = self._serialize(value)
        if self.use_redis and self.redis_client:
            self.redis_client.set(key, data)
        else:
            self.conn.execute(
                "REPLACE INTO state(key, value) VALUES (?, ?)", (key, data)
            )
            self.conn.commit()

    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """Retrieve a value by key, returning ``default`` if not present."""
        if self.use_redis and self.redis_client:
            value = self.redis_client.get(key)
            if value is None:
                return default
            return self._deserialize(value)
        else:
            cursor = self.conn.execute(
                "SELECT value FROM state WHERE key = ?", (key,)
            )
            row = cursor.fetchone()
            if row is None:
                return default
            return self._deserialize(row[0])

    # Convenience methods for commonly used keys
    def set_entry_price(self, symbol: str, price: float) -> None:
        self.set(f"entry_price:{symbol}", price)

    def get_entry_price(self, symbol: str) -> Optional[float]:
        return self.get(f"entry_price:{symbol}")

    def set_in_position(self, symbol: str, flag: bool) -> None:
        self.set(f"in_position:{symbol}", flag)

    def get_in_position(self, symbol: str) -> bool:
        return bool(self.get(f"in_position:{symbol}", False))

    def set_last_rebalance(self, timestamp: float) -> None:
        self.set("last_rebalance", timestamp)

    def get_last_rebalance(self) -> Optional[float]:
        return self.get("last_rebalance")