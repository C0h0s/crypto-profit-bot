"""Signal generation logic for the crypto‑profit trading bot.

This module contains utility functions used to decide whether the bot
should take profit, stop losses or continue holding a position. The logic
is intentionally simple and based solely on comparing current price to the
entry price multiplied by configurable thresholds.
"""

from __future__ import annotations

from typing import Optional


def take_profit_or_stop_loss(
    entry_price: Optional[float],
    current_price: Optional[float],
    x_take_profit: float,
    y_stop_loss: float,
) -> str:
    """Determine whether to sell based on take‑profit or stop‑loss thresholds.

    Parameters
    ----------
    entry_price : float or None
        The price at which the position was entered. If ``None``, no signal
        will be emitted and ``"hold"`` is returned.
    current_price : float or None
        The current market price. If ``None``, returns ``"hold"`` because
        without a price it's impossible to decide.
    x_take_profit : float
        Take‑profit percentage expressed as a whole number (e.g. ``5`` for 5%).
    y_stop_loss : float
        Stop‑loss percentage expressed as a whole number (e.g. ``2`` for 2%).

    Returns
    -------
    str
        One of ``"sell"`` or ``"hold"`` depending on whether the current
        price has breached the configured thresholds.
    """
    if entry_price is None or current_price is None:
        return "hold"
    # Convert percentages to decimal fractions
    tp_multiplier = 1 + (x_take_profit / 100.0)
    sl_multiplier = 1 - (y_stop_loss / 100.0)
    take_profit_price = entry_price * tp_multiplier
    stop_loss_price = entry_price * sl_multiplier
    if current_price >= take_profit_price:
        return "sell"
    if current_price <= stop_loss_price:
        return "sell"
    return "hold"